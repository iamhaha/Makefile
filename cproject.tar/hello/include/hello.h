/* File name: hello.h
 * * C header file
 * */

#ifndef HELLO_H
#define HELLO_H

#ifdef __cplusplus
extern "C" {
#endif

    void print_hello();

#ifdef __cplusplus
}
#endif

#endif
