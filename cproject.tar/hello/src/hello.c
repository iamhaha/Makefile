/* File name: hello.c
 * * C source file.
 * */
#include "hello.h"
#include "test.h"
#include <stdio.h>

void print_hello()
{
  puts( "Hello, world!" );
  }
