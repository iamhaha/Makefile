/*
++ source file.
*/
#include "hello.h"

int main()
{
  print_hello();

    return 0;
    }
